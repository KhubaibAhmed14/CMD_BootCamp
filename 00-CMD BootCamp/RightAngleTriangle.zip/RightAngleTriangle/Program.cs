﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RightAngleTriangle
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please provide the height of the right angle triangle: ");// Prompt for height of triangle
            int h = int.Parse(Console.ReadLine());//Getting the input from user
            for (int i = 0; i<=h; i++)
            {
                for (int k=0; k<i; k++)//Loop to print the right angle triangle
                {
                    Console.Write("*");
                        
                }
                Console.WriteLine("");

            }

        }
    }
}
