﻿using System;
namespace BankManagementSystem
{
    public interface IBankAccount   // Public interface which contains the methods that will be utilised in all the classes that share the interface.
    {
        void Deposit(int amount);
        void Withdraw(int amount);

    }
}
