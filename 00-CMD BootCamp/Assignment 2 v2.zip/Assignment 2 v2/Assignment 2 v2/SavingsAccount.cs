﻿using System;
namespace BankManagementSystem
{


    public class SavingsAccount : BankAccounts // Child class that inherits all the methods of the parent/base class. 
    {
        public double InterestR;
        public SavingsAccount(string name, int ac_num, double blnc, double iR) : base(name, ac_num, blnc) // Constructor for child class which accepts an additional parameter as iR.
        {
            InterestR = iR;
        }

        public override void Deposit(int amount) // Definition of Deposit method by overriding the Deposit method previously declared. 
        {
            balance += (1 + InterestR) * amount;

        }
        public override void Withdraw(int amount)// Definition of Withdraw method by overriding the Withdraw method previously declared.
        {
            if (amount > balance)
            {
                Console.WriteLine("Error: Insufficient Balance");
            }
            else
            { balance -= amount; }
        }
        public override void ExecuteTransaction(double amount)
        {
            Console.Write($"Transaction of {amount} has been successfully initiated.");
        }
        public override void PrintTransaction(double amount)
        {
            Console.Write($"Printing transaction receipt of  {amount} has been successfull.");
        }

        public override void CalculateInterest(double blnc)
        {
            balance  +=   InterestR * blnc;
        }
        public override void DisplayAccountInfo()
        {
            Console.WriteLine($"Name: {Name}");

            Console.WriteLine($"Account Number: {AC_number}");

            Console.WriteLine($"Balance: {balance}");
            Console.WriteLine("Account type: Savings Account");
        }


    }
}