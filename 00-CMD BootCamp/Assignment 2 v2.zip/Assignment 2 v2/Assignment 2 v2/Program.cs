﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankManagementSystem 
{

    class AMS
    {
        static void Main(string[] args)
        {
            Bank bank = new Bank(); // Create a new instance of Bank class and name the object as 'bank'
            SavingsAccount Myaccount = new SavingsAccount("Taimoor", 291006, 500000.00, 0.18); // Create a new instance of a SavingsAccount class named as Myaccount and pass it 4 parameters for its constructor.
            bank.AddAccount(Myaccount);//Use the AddAccount method on bank object and pass it Myaccount as input.
            Myaccount.DisplayAccountInfo();// Use Myaccount object and utilise the method of its parent class to display account info.
            CheckingAccount Myacc = new CheckingAccount("Asif", 284282, 500000.00);
            bank.AddAccount(Myacc);
            bank.DepositToAccount(Myacc, 30000);
            bank.WithdrawFromAccount(Myacc, 1000);
            Myacc.DisplayAccountInfo();
            Myaccount.Withdraw(10000000);
            LoanAccount Notmine = new LoanAccount("Ali", 283821, 105762.00, 3);
            bank.AddAccount(Notmine);
            Notmine.TakeLoan(100000);
            Notmine.ExecuteTransaction(100000.00);
            Notmine.PrintTransaction(100000.00);
            Notmine.CalculateInterest(100000.00);
            Notmine.DisplayAccountInfo();
        }
    }
}
