﻿using System;
namespace BankManagementSystem
{
    public class CheckingAccount : BankAccounts
    {
        public CheckingAccount(string name, int ac_num, double blnc) : base(name, ac_num, blnc)
        { }
        public double intrate = 0.1;
        public override void Withdraw(int amount) // Overriding the existing Withdraw method in the child  class
        {
            if (amount > balance)
            {
                Console.WriteLine("Your balance is insufficient for the amount you are trying to withdraw");

            }
            else
            {
                balance -= amount;
            }
        }
        public override void Deposit(int amount)
        {
            balance += amount;

        }

        public override void ExecuteTransaction(double amount)
        {
            Console.Write($"Transaction of {amount} has been successfully initiated.");
        }

        public override void PrintTransaction(double amount)
        {
            Console.Write($"Printing transaction receipt of  {amount} has been successfull.");
        }

        public override void CalculateInterest(double blnc)
        {
            balance += intrate * blnc;
        }
        public override void DisplayAccountInfo()
        {
            Console.WriteLine($"Name: {Name}");

            Console.WriteLine($"Account Number: {AC_number}");

            Console.WriteLine($"Balance: {balance}");
            Console.WriteLine("Account type: Checking Account");
        }


    }
}