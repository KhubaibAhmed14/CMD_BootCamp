﻿using System;
using System.Collections.Generic;
namespace BankManagementSystem
{
    public class Bank
    {
        public List<BankAccounts> accounts;
        public Bank()
        {
            accounts = new List<BankAccounts>();
        }
        public void AddAccount(BankAccounts account)
        {
            accounts.Add(account);
            Console.WriteLine($"Your account: {account.Name} has been added successfully.");
        }
        public void DepositToAccount(BankAccounts accounT, int amount)
        {
            bool state = false;
            foreach (BankAccounts account in accounts)
            {
                if (account == accounT)
                {
                    account.balance += amount;
                    Console.WriteLine($"{accounT.Name} has successfully deposited {amount} into the account.");
                    state = true;
                }

            }
            if (state == false)
            {
                Console.WriteLine("Account not found.");
            }
        }

        public void WithdrawFromAccount(BankAccounts accounT, int amount)
        {
            bool state = false;
            foreach (BankAccounts account in accounts)
            {
                if (account == accounT)
                {
                    account.balance -= amount;
                    Console.WriteLine($"{accounT.Name} has successfully withdrawn {amount} from the account.");
                    state = true;
                }

            }
            if (state == false)
            {
                Console.WriteLine("Account not found.");
            }
        }
    }
}