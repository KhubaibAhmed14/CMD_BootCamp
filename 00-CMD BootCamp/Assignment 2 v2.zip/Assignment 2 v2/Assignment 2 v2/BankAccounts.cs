﻿using System;
namespace BankManagementSystem 
{

    public abstract class BankAccounts : IBankAccount , ITransaction  // Abstract class that contains the methods of the interface and has implementation in the class.
    {
        public string Name { get; set; }
        public int AC_number { get; set; }
        public double balance { get; set; }

        public BankAccounts(string name, int ac_num, double blnc) // Constructor for the base class which takes three parameters as arguments every time it is called.
        {
            Name = name;
            AC_number = ac_num;
            balance = blnc;

        }

        public abstract void Deposit(int amount); // Declaration of the abstract method. The body is missing since this is an abstract method and will be overriden later in the child class.
        public abstract void ExecuteTransaction(double amount);
        public abstract void Withdraw(int amount);
        public abstract void PrintTransaction(double amount);
        public abstract void CalculateInterest(double amount);
        public abstract void DisplayAccountInfo();


    }
}
   

