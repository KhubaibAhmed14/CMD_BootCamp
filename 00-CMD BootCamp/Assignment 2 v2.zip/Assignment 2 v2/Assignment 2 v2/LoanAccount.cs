﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankManagementSystem
{
    class LoanAccount:BankAccounts
    {
        public int LoanDura { get; set; }
        public double ir = 0.18;
        public double interest = 0;
        private int loanAmount { get; set; }
        public LoanAccount(string name, int ac_num, double blnc, int loanDuration) : base( name,  ac_num, blnc)
        {
            loanAmount = (int)(blnc);
             LoanDura = loanDuration;   
        }
        public void TakeLoan(int amount)
        {
            loanAmount += amount; 
            Console.WriteLine($"The request for loan of {amount} has been initiated.");
        }
        public override void Deposit(int amount) // Definition of Deposit method by overriding the Deposit method previously declared. 
        {
            loanAmount -=  amount;
        }
        public override void Withdraw(int amount)
        {
            loanAmount += amount;
        }
        public override void CalculateInterest(double amount)
        {
            interest = LoanDura * ir *amount;
        }
        public override void ExecuteTransaction(double amount)
        {
            Console.WriteLine($"Transaction of {amount} has been successfully initiated.");
        }

        public override void PrintTransaction(double amount)
        {
            Console.WriteLine ($"Printing transaction receipt of  {amount} has been successfull.");
        }

        public override void DisplayAccountInfo()
        {
            Console.WriteLine($"Name: {Name}");

            Console.WriteLine($"Account Number: {AC_number}");

            Console.WriteLine($"Loan due: {loanAmount+interest}");
            Console.WriteLine("Account type: Loan Account");
        }


    }
}
