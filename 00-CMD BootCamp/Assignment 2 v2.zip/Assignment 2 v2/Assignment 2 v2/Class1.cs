﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankManagementSystem 
{

    public abstract class BankAccounts : IBankAccount  // Abstract class that contains the methods of the interface and has implementation in the class.
    {
        public string Name;
        public int AC_number;
        public double balance;

        public BankAccounts(string name, int ac_num, double blnc) // Constructor for the base class which takes three parameters as arguments every time it is called.
        {
            Name = name;
            AC_number = ac_num;
            balance = blnc;

        }

        public abstract void Deposit(int amount); // Declaration of the abstract method. The body is missing since this is an abstract method and will be overriden later in the child class.


        public abstract void Withdraw(int amount);

        public abstract void DisplayAccountInfo();


    }
}
   
}
