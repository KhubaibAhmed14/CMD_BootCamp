﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Triangle
{
    class Triangle
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please provide the number of rows for triangle: ");// Prompt for number of rows of triangle
            int r = int.Parse(Console.ReadLine());//Getting the input from user
            for (int i = 1; i <= r; i++)
            {
                for (int k = 1; k <= r-i; k++)//Loop to print space characters 
                {
                    
                    Console.Write(" ");

                }
                for (int l = 1; l <= 2*i-1; l++)// Loop that iterates to print *
                {
                    Console.Write("*");
                }
                Console.WriteLine("");

            }

        }
    }
}
