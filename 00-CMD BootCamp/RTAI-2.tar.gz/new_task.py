import sys
import pika


connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
channel = connection.channel()

# sys.argv[1:]: This is a list containing all the command-line arguments passed to the script. sys.argv[0] is the name of the script itself, so sys.argv[1:] represents all the arguments from the first one onwards.
message = ' '.join(sys.argv[1:]) or "Hello World!."

# When RabbitMQ quits or crashes it will forget the queues and messages unless you tell it not to. Two things are required to make sure that messages aren't lost: we need to mark both the queue and messages as durable.
channel.queue_declare(queue='task_queue' ,durable=True)

channel.basic_publish(exchange='', routing_key='hello', body=message, properties=pika.BasicProperties(delivery_mode=pika.spec.PERSISTENT_DELIVERY_MODE))
print(f" [x] Sent {message}")

# Marking messages as persistent doesn't fully guarantee that a message won't be lost. Although it tells RabbitMQ to save the message to disk, there is still a short time window when RabbitMQ has accepted a message and hasn't saved it yet. 
