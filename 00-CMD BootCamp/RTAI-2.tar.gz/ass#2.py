import pika
import multiprocessing
import time

A = 2
B = 6

def service_a(q_b_to_a, event_ab, event_ba, max_iterations):
    connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
    channel = connection.channel()
    channel.queue_declare(queue='queue_a_to_b')
    
    def callback(ch, method, properties, body):
        X = int(body)
        q_b_to_a.put(X)  # Put data into Queue B-to-A
        print(f"Service A: Published {X} to Queue B-to-A")
        event_ab.set()  # Signal Service B
        event_ba.wait()  # Wait for Service B
        event_ba.clear()
    
    channel.basic_consume(queue='queue_b_to_a', on_message_callback=callback, auto_ack=True)
    
    for _ in range(max_iterations):
        X = A * B
        channel.basic_publish(exchange='', routing_key='queue_a_to_b', body=str(X))
        print(f"Iteraion:{_+1} Service A: Published {X} to Queue A-to-B")
        event_ab.set()  # Signal Service B
        event_ba.wait()  # Wait for Service B
        event_ba.clear()

        channel.basic_consume(queue='queue_a_to_b', on_message_callback=callback, auto_ack=True)

def service_b(q_a_to_b, event_ab, event_ba, max_iterations):
    connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
    channel = connection.channel()
    channel.queue_declare(queue='queue_b_to_a')
    
    def callback(ch, method, properties, body):
        X = int(body)
        X = X ** 2
        channel.basic_publish(exchange='', routing_key='queue_b_to_a', body=str(X))
        print(f"Service B: Published {X} to Queue B-to-A")
        event_ba.set()  # Signal Service A
        event_ab.wait()  # Wait for Service A
        event_ab.clear()
    
    channel.basic_consume(queue='queue_a_to_b', on_message_callback=callback, auto_ack=True)
    
    for _ in range(max_iterations):
        event_ab.wait()  # Wait for Service A
        event_ab.clear()

if __name__ == "__main__":
    max_iterations = int(input("Enter max_iterations: "))
    
    event_ab = multiprocessing.Event()  # Event for synchronization between A and B
    event_ba = multiprocessing.Event()  # Event for synchronization between B and A
    
    q_a_to_b = multiprocessing.Queue()
    q_b_to_a = multiprocessing.Queue()
    
    process_a = multiprocessing.Process(target=service_a, args=(q_b_to_a, event_ab, event_ba, max_iterations))
    process_b = multiprocessing.Process(target=service_b, args=(q_a_to_b, event_ab, event_ba, max_iterations))

    process_a.start()
    process_b.start()
    
    time.sleep(1)  # Allow some time for initialization

    event_ab.set()  # Start with Service A
    process_a.join()
    process_b.join()