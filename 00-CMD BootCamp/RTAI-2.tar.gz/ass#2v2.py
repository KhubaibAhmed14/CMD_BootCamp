import pika, multiprocessing

X = 2
B = 6


n = int(input("Enter the no of iterations : "))
a = 0
b = 0

def serviceA(n):
    import pika
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()
    channel.queue_declare(queue='Q1' ,durable=True)
    channel.queue_declare(queue='Q2' ,durable=True)

    def callback(ch, method, properties, body):
        print(f"Received from Q2 {body}", flush=True)
        body = body.decode()
        X = (int(body))*B

        global a
        a = a + 1
        if a < n:
            channel.basic_publish(exchange='', routing_key='Q1', body=str(X))
            print(f"\t\t\tSent {X} to Q1")
        else:
            connection.close()
        
    channel.basic_consume(queue='Q2', on_message_callback=callback, auto_ack=True)

    channel.start_consuming()


def serviceB(n):
    import pika
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()
    channel.queue_declare(queue='Q1' ,durable=True)
    channel.queue_declare(queue='Q2' ,durable=True)

    channel.basic_publish(exchange='', routing_key='Q2', body=str(2))
    def callback(ch, method, properties, body):
        print(f"Received from Q1 {str(body)}", flush=True)
        body = body.decode()
        X = (int(body))**2

        global b
        b = b + 1
        if b < n:
            channel.basic_publish(exchange='', routing_key='Q2', body=str(X))
            print(f"\t\t\tSent {X} to Q2")
        else:
            connection.close()

    channel.basic_consume(queue='Q1', on_message_callback=callback, auto_ack=True)
    channel.start_consuming()


processA = multiprocessing.Process(target=serviceA, args=(n, ))
processB = multiprocessing.Process(target=serviceB, args=(n, ))

processA.start()
processB.start()

processA.join()
processB.join()

